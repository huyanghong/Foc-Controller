#ifndef FOC_FOCCONTROLLER_H_
#define FOC_FOCCONTROLLER_H_

#include <FOC/FocConverter.h>
#include <FOC/SvPwm.h>
#include "FOC/MagneticSensorSPI.h"
#include "FOC/IncrementalEncoder.h"
#include "FOC/AdcValue.h"


class FocController {
public:
	FocController();
	virtual ~FocController();
	FocController(FocConverter *foc_Conv, SvPwm *sv_pwm, Encoder *sen, AdcValue *adc){
		this->Adc = adc;
		this->Sensor = sen;
		this->Svpwm = sv_pwm;
		this->FocConv = foc_Conv;
	};


	AdcValue *Adc;
	Encoder *Sensor;
	FocConverter *FocConv;
	SvPwm *Svpwm;

	void Init();
	void Run();
	void Ctrl();

	int t[5];

	float DeltaT;
	unsigned long Timestamp;
	float Udc; //电源电压
	int PolePair;

	float ElectronicAngle, MechanicalAngle, OffsetAngle;
//	float OpenLoopTheta;

	Pid PidSpeed;
	Pid PidPosition;

	enum {CW = -1, CCW = 1} Dir = this->CCW;
	enum {FOC_Disable, FOC_Voltage, FOC_Current, FOC_Speed, FOC_Position} Mode = this->FOC_Disable;
	enum {Ctrl_Idle, Ctrl_Init, Ctrl_Wait, Ctrl_Run, Ctrl_Stop} Task = this->Ctrl_Idle;

	struct{
		float TargetCurrent;
		float TargetSpeed;
		float TargetPosition;
		struct{
			float Theta;
			float Uq, Ud;
		}InjectionVoltage;
	}CtrlPara;
};

#endif /* FOC_FOCCONTROLLER_H_ */
