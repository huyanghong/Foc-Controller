#include <FOC/FocController.h>
#include "FreeRTOS.h"
#include "task.h"

FocController::FocController() {
	// TODO Auto-generated constructor stub
}

FocController::~FocController() {
	// TODO Auto-generated destructor stub
}

void FocController::Init() {
	this->PolePair = 7;
	this->Udc = 12;
	this->Svpwm->Udc = this->Udc;

	this->FocConv->Um = sqrt(3) / 3.0 * this->Udc;

	this->FocConv->PidD.Kp = 2.58;
	this->FocConv->PidD.Ki = 92.25;
	this->FocConv->PidD.Integral_Attenuation = 0.99;
	this->FocConv->PidD.Kd = 0;
	this->FocConv->PidD.Limit_Error = 0.1f;
	this->FocConv->PidD.Limit_Integral = this->FocConv->Um;
	this->FocConv->PidD.Limit_Result = this->FocConv->Um;
	this->FocConv->PidQ.Kp = 2.58;
	this->FocConv->PidQ.Ki = 92.25;
	this->FocConv->PidQ.Integral_Attenuation = 0.99;
	this->FocConv->PidQ.Kd = 0;
	this->FocConv->PidQ.Limit_Error = 0.1f;
	this->FocConv->PidQ.Limit_Integral = this->FocConv->Um;
	this->FocConv->PidQ.Limit_Result = this->FocConv->Um;

	this->PidSpeed.Kp = 6;
	this->PidSpeed.Ki = 12;
	this->PidSpeed.Integral_Attenuation = 0.99;
	this->PidSpeed.Kd = 0;
	this->PidSpeed.Limit_Error = 100;
	this->PidSpeed.Limit_Integral = 1.0;
	this->PidSpeed.Limit_Result = 1.0f;

	this->PidPosition.Kp = 4.25;
	this->PidPosition.Ki = 4.29;
	this->PidPosition.Integral_Attenuation = 1;
	this->PidPosition.Kd = 34;
	this->PidPosition.Limit_Error = 1;
	this->PidPosition.Limit_Integral = 1.0;
	this->PidPosition.Limit_Result = 1.0f;

	this->Adc->Offset(1000);
	this->Mode = FocController::FOC_Disable;
	this->Adc->Start();
}

int AlignmentCnt = 2500;
float volt = 2;
void FocController::Ctrl() {
	switch(this->Task){
		case FocController::Ctrl_Idle:
			this->Mode = this->FOC_Disable;
			break;
		case FocController::Ctrl_Init:
			if(AlignmentCnt){
				this->Mode = FocController::FOC_Voltage;
				this->CtrlPara.InjectionVoltage.Ud = volt;
				this->CtrlPara.InjectionVoltage.Uq = 0;
				this->CtrlPara.InjectionVoltage.Theta = 0;
				AlignmentCnt--;
				this->OffsetAngle = 0.9 * this->OffsetAngle + 0.1 * this->Sensor->GetAngle();
				if(AlignmentCnt == 0){
					this->CtrlPara.InjectionVoltage.Ud = 0;
					vTaskDelay(100);
					this->Task = FocController::Ctrl_Wait;
				}
			}
			break;
		case FocController::Ctrl_Wait:
			this->Mode = FocController::FOC_Speed;
			this->CtrlPara.TargetCurrent = 0;
			this->Task = FocController::Ctrl_Run;
			break;
		case FocController::Ctrl_Run:
			this->CtrlPara.TargetSpeed = -60.2;
			vTaskDelay(8000);
			this->CtrlPara.TargetSpeed = 60.2;
			vTaskDelay(8000);
			break;
		case FocController::Ctrl_Stop:
			this->Mode = this->FOC_Disable;
			break;
	}
}
void FocController::Run() {
	this->Svpwm->PwmOutput(this->Svpwm->T1, this->Svpwm->T2, this->Svpwm->T3);

	unsigned long timestamp_us = micros();
	this->DeltaT = (timestamp_us - this->Timestamp) * 1e-6;
	if(this->DeltaT <= 0 || this->DeltaT > 0.5) this->DeltaT = 1e-4;
	this->Timestamp = timestamp_us;

	this->Sensor->Update();
	this->MechanicalAngle = this->Sensor->GetAngle();
	this->ElectronicAngle = (this->MechanicalAngle - this->OffsetAngle) * this->PolePair;
	this->t[1] = micros() - timestamp_us;

	this->Adc->Update(this->Svpwm->LastSector);
	this->t[2] = micros() - timestamp_us;
	switch(this->Mode){
		case FocController::FOC_Disable:
			this->Svpwm->T1 = 0;
			this->Svpwm->T2 = 0;
			this->Svpwm->T3 = 0;
			this->Svpwm->LastSector = this->Svpwm->Sector = 0;
			break;
		case FocController::FOC_Voltage:
			this->FocConv->Ud = this->CtrlPara.InjectionVoltage.Ud;
			this->FocConv->Uq = this->CtrlPara.InjectionVoltage.Uq;
			this->FocConv->Theta = this->CtrlPara.InjectionVoltage.Theta * this->PolePair;

			this->FocConv->RevPark(this->FocConv->Ud, this->FocConv->Uq, this->FocConv->Theta);
			this->Svpwm->Svpwm(this->FocConv->Ualpha, this->FocConv->Ubeta);
//			this->Svpwm->PwmOutput(this->Svpwm->T1, this->Svpwm->T2, this->Svpwm->T3);
			break;
		case FocController::FOC_Current:
			this->FocConv->Clarke(this->Adc->Value.iu, this->Adc->Value.iv, this->Adc->Value.iw);
			this->FocConv->Theta = this->ElectronicAngle;
			this->FocConv->Park();
			this->t[3] = micros() - timestamp_us;
			this->FocConv->PidD.Target = 0;
			this->FocConv->PidD.Actual = this->FocConv->Id;
			this->FocConv->PidD.DeltaT = this->DeltaT;
			this->FocConv->PidD.PidProcess();
			this->FocConv->Ud = this->FocConv->PidD.Result;

			this->FocConv->PidQ.Target = this->CtrlPara.TargetCurrent;
			this->FocConv->PidQ.Actual = this->FocConv->Iq;
			this->FocConv->PidQ.DeltaT = this->DeltaT;
			this->FocConv->PidQ.PidProcess();
			this->FocConv->Uq = this->FocConv->PidQ.Result;

			this->FocConv->RevPark();
			this->Svpwm->Svpwm(this->FocConv->Ualpha, this->FocConv->Ubeta);
//			this->Svpwm->PwmOutput(this->Svpwm->T1, this->Svpwm->T2, this->Svpwm->T3);
			break;
		case FocController::FOC_Speed:
			this->PidSpeed.Actual = 0.99 * this->PidSpeed.Actual  + 0.01*this->Sensor->GetVelocity();
			this->PidSpeed.DeltaT = this->DeltaT;
			this->PidSpeed.PidProcess(this->CtrlPara.TargetSpeed);
			this->CtrlPara.TargetCurrent = this->PidSpeed.Result;

			this->FocConv->Clarke(this->Adc->Value.iu, this->Adc->Value.iv, this->Adc->Value.iw);
			this->FocConv->Theta = this->ElectronicAngle;
			this->FocConv->Park();
			this->t[3] = micros() - timestamp_us;

			this->FocConv->PidD.Target = 0;
			this->FocConv->PidD.Actual = this->FocConv->Id;
			this->FocConv->PidD.DeltaT = this->DeltaT;
			this->FocConv->PidD.PidProcess();
			this->FocConv->Ud = this->FocConv->PidD.Result;

			this->FocConv->PidQ.Target = this->CtrlPara.TargetCurrent;
			this->FocConv->PidQ.Actual = this->FocConv->Iq;
			this->FocConv->PidQ.DeltaT = this->DeltaT;
			this->FocConv->PidQ.PidProcess();
			this->FocConv->Uq = this->FocConv->PidQ.Result;

			this->FocConv->RevPark();
			this->Svpwm->Svpwm(this->FocConv->Ualpha, this->FocConv->Ubeta);
//			this->Svpwm->PwmOutput(this->Svpwm->T1, this->Svpwm->T2, this->Svpwm->T3);
			break;
		case FocController::FOC_Position:
			this->PidPosition.Actual = this->MechanicalAngle;
			this->PidPosition.DeltaT = this->DeltaT;
			this->PidPosition.PidProcess(this->CtrlPara.TargetPosition);
			this->CtrlPara.TargetCurrent = this->PidPosition.Result;

			this->FocConv->Clarke(this->Adc->Value.iu, this->Adc->Value.iv, this->Adc->Value.iw);
			this->FocConv->Theta = this->ElectronicAngle;
			this->FocConv->Park();
			this->t[3] = micros() - timestamp_us;

			this->FocConv->PidD.Target = 0;
			this->FocConv->PidD.Actual = this->FocConv->Id;
			this->FocConv->PidD.DeltaT = this->DeltaT;
			this->FocConv->PidD.PidProcess();
			this->FocConv->Ud = this->FocConv->PidD.Result;

			this->FocConv->PidQ.Target = this->CtrlPara.TargetCurrent;
			this->FocConv->PidQ.Actual = this->FocConv->Iq;
			this->FocConv->PidQ.DeltaT = this->DeltaT;
			this->FocConv->PidQ.PidProcess();
			this->FocConv->Uq = this->FocConv->PidQ.Result;

			this->FocConv->RevPark();
			this->Svpwm->Svpwm(this->FocConv->Ualpha, this->FocConv->Ubeta);
//			this->Svpwm->PwmOutput(this->Svpwm->T1, this->Svpwm->T2, this->Svpwm->T3);
			break;
	}
	this->t[4] = micros() - timestamp_us;
}
