#include <FOC/AdcValue.h>

AdcValue::AdcValue() {
	// TODO Auto-generated constructor stub
}

AdcValue::~AdcValue() {
	// TODO Auto-generated destructor stub
}

void AdcValue::Offset(int cnt){
	unsigned int iu = 0, iv = 0, iw = 0;

	if(this->Adc3){
		HAL_ADC_Start(this->Adc1);
		HAL_ADC_Start(this->Adc2);
		HAL_ADC_Start(this->Adc3);

		for(int i=0; i<cnt; i++){
			iu += HAL_ADCEx_InjectedGetValue(this->Adc1, this->Rank1);
			iv += HAL_ADCEx_InjectedGetValue(this->Adc2, this->Rank2);
			iw += HAL_ADCEx_InjectedGetValue(this->Adc3, this->Rank3);
			HAL_Delay(1);
		}
		this->OffsetValue.iu = (float)iu / cnt * this->Adc2Amps;
		this->OffsetValue.iv = (float)iv / cnt * this->Adc2Amps;
		this->OffsetValue.iw = (float)iw / cnt * this->Adc2Amps;
	}else{
		HAL_ADC_Start(this->Adc1);
		HAL_ADC_Start(this->Adc2);

		for(int i=0; i<cnt; i++){
			iu += HAL_ADCEx_InjectedGetValue(this->Adc1, this->Rank1);
			iv += HAL_ADCEx_InjectedGetValue(this->Adc2, this->Rank2);
			HAL_Delay(1);
		}
		this->OffsetValue.iu = (float)iu / cnt * this->Adc2Amps;
		this->OffsetValue.iv = (float)iv / cnt * this->Adc2Amps;
		this->OffsetValue.iw = 0;
	}
}

void AdcValue::Update(int _sector){
	unsigned int iu = 0, iv = 0, iw = 0;

	if(this->Adc3){
		iu = HAL_ADCEx_InjectedGetValue(this->Adc1, this->Rank1);
		iv = HAL_ADCEx_InjectedGetValue(this->Adc2, this->Rank2);
		iw = HAL_ADCEx_InjectedGetValue(this->Adc3, this->Rank3);
		if(iu > 4095) iu = 4095;
		if(iv > 4095) iv = 4095;
		if(iw > 4095) iw = 4095;

		this->Value.iu = this->OffsetValue.iu - iu * this->Adc2Amps;
		this->Value.iv = this->OffsetValue.iv - iv * this->Adc2Amps;
		this->Value.iw = this->OffsetValue.iw - iw * this->Adc2Amps;
		if(_sector == 1 || _sector == 6)
			this->Value.iu = -this->Value.iv - this->Value.iw;
		else if(_sector == 2 || _sector == 3)
			this->Value.iv = -this->Value.iu - this->Value.iw;
		else if(_sector == 4 || _sector == 5)
			this->Value.iw = -this->Value.iu - this->Value.iv;
	}else{
		iu = HAL_ADCEx_InjectedGetValue(this->Adc1, this->Rank1);
		iv = HAL_ADCEx_InjectedGetValue(this->Adc2, this->Rank2);
		if(iu > 4095) iu = 4095;
		if(iv > 4095) iv = 4095;

		this->Value.iu = this->OffsetValue.iu - iu * this->Adc2Amps;
		this->Value.iv = this->OffsetValue.iv - iv * this->Adc2Amps;
		this->Value.iw = -this->Value.iu - this->Value.iv;
	}
}
