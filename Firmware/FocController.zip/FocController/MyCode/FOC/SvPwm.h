#ifndef FOC_SVPWM_H_
#define FOC_SVPWM_H_

#include "tim.h"

#define SVPWM_SQRT3_2 0.8660254f
#define SVPWM_SQRT3   1.7320508f

class SvPwm {
public:
	SvPwm();
	virtual ~SvPwm();

	SvPwm(TIM_HandleTypeDef* tim, int period);

	TIM_HandleTypeDef* Tim;

	int Period = 4200;
	int T1, T2, T3;
	float Udc = 12;
	int Sector, LastSector;

	void Svpwm(float uAlpha, float uBeta);
	void Svpwm();

	void PwmOutput(int t1, int t2, int t3){
		if(t1 > Period) t1 = Period;
		if(t2 > Period) t2 = Period;
		if(t3 > Period) t3 = Period;
		if(t1 < 0) t1 = 0;
		if(t2 < 0) t2 = 0;
		if(t3 < 0) t3 = 0;
		this->Tim->Instance->CCR1 = t1;
		this->Tim->Instance->CCR2 = t2;
		this->Tim->Instance->CCR3 = t3;
	}
	void PwmOutput(){
		PwmOutput(T1, T2, T3);
	}
};

#endif /* FOC_SVPWM_H_ */
