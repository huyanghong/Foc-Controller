#include <HardwareCan.h>

//HardwareCan::HardwareCan() {
//	// TODO Auto-generated destructor stub
//}
void HardwareCan::DoProtocol(void){

}

HardwareCan::~HardwareCan() {
	// TODO Auto-generated destructor stub
}

