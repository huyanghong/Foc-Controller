#include "main.h"
#include "cmsis_os.h"
#include "FreeRTOS.h"
#include "task.h"
#include "stdio.h"
#include "usart.h"
#include "tim.h"
#include "can.h"
#include "HardwareCan.h"
#include "Shycom.h"
#include <FOC/FocController.h>

Shycom shycom(UART4, 1500000);
//AdcValue *adcValue = new AdcValue(0.1f, 10.0, &hadc1, ADC_INJECTED_RANK_1, &hadc2, ADC_INJECTED_RANK_1, &hadc3, ADC_INJECTED_RANK_1);
AdcValue *adcValue = new AdcValue(9100, 1.0/9200.0, &hadc1, ADC_INJECTED_RANK_1, &hadc2, ADC_INJECTED_RANK_1, &hadc3, ADC_INJECTED_RANK_1);
//Encoder *sensor = new MagneticSensorSPI(&hspi1, GPIOA, GPIO_PIN_4, 0x3fff, 16384, MagneticSensorSPI::CW);
Encoder *sensor = new IncrementalEncoder(&htim3, 64000, MagneticSensorSPI::CCW);
SvPwm *svpwm = new SvPwm(&htim1, 4200);
FocConverter *focConv = new FocConverter();
FocController focController(focConv, svpwm, sensor, adcValue);

void StartFocTask(void *argument)
{
	focController.Init();
	vTaskDelay(100);
	focController.Task = FocController::Ctrl_Init;
	while(1){
		vTaskDelay(1);
		focController.Ctrl();
	}
}

void protocolTask(void *argument){
	shycom.Begin();
	while(1){
		vTaskDelay(100);
		if((millis() - shycom.GetRxTimeStamp()) > 500 /*&& shycom.GetAvailable() > 0*/){
			shycom.DoProtocol();
		}
		shycom.printf("%d %d %d %d %d %d %f %f %f %f %f %f %f %f\n",focController.t[0],	focController.t[4],
													svpwm->Sector,svpwm->T1,	svpwm->T2,	svpwm->T3,
													focController.Adc->OffsetValue.iu,	focController.Adc->OffsetValue.iv,	focController.Adc->OffsetValue.iw,
													focController.Adc->Value.iu,	focController.Adc->Value.iv,	focController.Adc->Value.iw,
													focController.FocConv->Id,	focController.FocConv->Iq);

	}
}



unsigned int t;
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* AdcHandle)
{
  /* Get the converted value of injected channel */
	if(AdcHandle->Instance == ADC1){
		focController.Run();
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_2);
		focController.t[0] = micros() - t;
		t = micros();
	}else if(AdcHandle->Instance == ADC2){

	}else if(AdcHandle->Instance == ADC3){

	}
}

extern volatile uint8_t Uart4_RxBuffer[1];
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle)
{
	if(UartHandle->Instance == UART4){
		shycom.Add(Uart4_RxBuffer[0]);
		HAL_UART_Receive_IT(&huart4, (uint8_t *)Uart4_RxBuffer, 1);
	}
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	uint8_t buf[8];
	CAN_RxHeaderTypeDef CAN_RX_HDR;
	if (hcan->Instance == hcan1.Instance){
		if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &CAN_RX_HDR, buf) == HAL_OK){
			uint32_t p;
//			memcpy(&p, buf, 4);
//			printf("pending1: %d %d %d %d %d\n", CAN_RX_HDR.DLC,CAN_RX_HDR.StdId,p,buf[0],buf[7]);
			HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING);	// 再次使能FIFO0接收中断
		}
	}
}


